package com.qozix.tileview.detail;

public interface DetailLevelEventListener {
	public void onDetailLevelChanged();
	public void onDetailScaleChanged(double scale);
}
