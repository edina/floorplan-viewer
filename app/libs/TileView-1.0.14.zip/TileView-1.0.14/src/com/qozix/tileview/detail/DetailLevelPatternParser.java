package com.qozix.tileview.detail;

public interface DetailLevelPatternParser {
	public String parse( String pattern, int row, int column );
}
