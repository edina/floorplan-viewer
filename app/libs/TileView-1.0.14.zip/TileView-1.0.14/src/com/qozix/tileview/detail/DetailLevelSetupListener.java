package com.qozix.tileview.detail;

public interface DetailLevelSetupListener {
	public void onDetailLevelAdded();
}
