package com.qozix.tileview.markers;

import android.view.View;

public interface MarkerEventListener {
	public void onMarkerTap( View view, int x, int y );
}
